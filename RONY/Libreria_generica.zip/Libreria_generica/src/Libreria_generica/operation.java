package Libreria_generica;

public interface operation <N extends Number> {
	public default N maxNumber(N...numbers) {
		N max=numbers[0];
		for(N n:numbers) {
			if (max.intValue()<n.intValue())
				max=n;
		}
		return max;
		
	}
	public default double sumatory(N...numbers) {
		double res=0.0;
		for(N n:numbers) {
			res+=n.doubleValue();
			
		}
		return res;
	}

}
