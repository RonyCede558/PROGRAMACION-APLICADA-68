package ejercicio2_claseGenerica;

public class pet {
	private generic <Integer>dt1_pet;
	private generic<String>dt2_pet;
	
	public pet(int id_pet, String namePet, String ownerPet) {
		dt1_pet=new generic(id_pet);
		dt2_pet=new generic(namePet,ownerPet);
	}
	
	public int getID() {
		return dt1_pet.getAttributeT1();	
	}
	
	public String getName() {
		return dt2_pet.getAttributeT1();
	}
	
	public String getOwner() {
		return dt2_pet.getAttributeT2();
	}
	public String info() {
		// TODO Auto-generated method stub
		return String.format("ID:%d-%s-Dueño: %s", getID(), getName(),getOwner());
	}
}
