package ejercicio2_claseGenerica;

import java.util.ArrayList;
import java.util.List;

public class main {

	public static void main(String[] args) {
		List<pet>pets=new ArrayList();
		pets.add(new pet(1234,"Rex","Alejandro"));
		pets.add(new pet(1478,"scrapy", "Mario"));
		pets.add(new pet(2587,"Firulais","Marco"));
		
		for(pet p:pets) {
			System.out.println(p.info());
		}
	}
	
}
