package ejercicio2_claseGenerica;

public class medicalRecord {
	private generic<Integer>dt1_mr;
	private generic<String>dt2_mr;
	
	public medicalRecord(int id, int idPet, String desc) {
		dt1_mr=new generic(id, idPet);
		dt2_mr=new generic(desc);
	}
	
	public int getId(){
		return this.dt1_mr.getAttributeT1();
	}
	
	public int getIdPet() {
		return dt1_mr.getAttributeT2();
	}
	
	public String getDesc() {
		return dt2_mr.getAttributeT1();
	}
}
